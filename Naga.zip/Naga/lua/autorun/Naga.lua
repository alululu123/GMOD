--Add Playermodel
player_manager.AddValidModel( "Naga", "models/PM/Naga_PM.mdl" )                         --PM模型
player_manager.AddValidHands( "Naga", "models/arms/Naga_arms.mdl", 0, "00000000" )      --PM手模

local Category = "Nikke-NEOWORLD"                                                                        --NPC MOD分类

local NPC = 
{
	Name = "Naga(Friendly)",                                                            --友好NPC名字
	Class = "npc_citizen", 
	Health = "150",                                                                    --NPC血量
	KeyValues = { citizentype = 4 }, 
	Model = "models/NPC/Naga_npc.mdl",                                                  --友好NPC模型
	Weapons = { "weapon_ar2","weapon_smg1"},                                           --NPC出生自带武器
	Category = Category
}

list.Set( "NPC", "Naga_friendly", NPC )

local NPC =
{
	Name = "Naga(Enemy)",                                                                --敌人NPC名字
	Class = "npc_combine_s",
	Health = "150",
	Numgrenades = "4",
	Model = "models/NPC/Naga_npc.mdl",                                                  --敌人NPC模型
	Weapons = { "weapon_ar2","weapon_smg1"},
	Category = Category
}

list.Set( "NPC", "Naga_enemy", NPC )
