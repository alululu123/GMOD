concommand.Add("Nagisa_Swimsuit_eyelight", function(ply, cmd, args)
    if #args < 1 then
        print("how-to-use: Nagisa_Swimsuit <0-1>")
        print("example: Nagisa_Swimsuit 0.5")
        return
    end
    
    local value = tonumber(args[1])
    if not value then
        print("false!: Need-Number!")
        return
    end
    
    value = math.Clamp(value, 0, 1)
    
    local material = Material("tex/Nagisa_Swimsuit/eye")
    if material and not material:IsError() then
        material:SetFloat("$detailblendfactor", value)
        print("finished!: " .. value)
    else
        print("false!: Texture-Lost! tex/Nagisa_Swimsuit/eye")
    end

    local material = Material("tex/Nagisa_Swimsuit/eye3")
    if material and not material:IsError() then
        material:SetFloat("$detailblendfactor", value)
        print("finished!: " .. value)
    else
        print("false!: Texture-Lost! tex/Nagisa_Swimsuit/eye3")
    end



end)