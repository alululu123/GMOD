local halo_enabled = CreateConVar("Nagisa_Swimsuit_halo", 10, {FCVAR_REPLICATED, FCVAR_ARCHIVE})

local models_for_character = {
    'models/npc/nagisa_Swimsuit_npc.mdl',
    'models/pm/nagisa_Swimsuit_pm.mdl'
}

local function SafeSetBodygroup(ent, bodygroupName, value)
    if not IsValid(ent) then return false end
    local bodygroupID = ent:FindBodygroupByName(bodygroupName)
    if bodygroupID and bodygroupID >= 10 then
        ent:SetBodygroup(bodygroupID, value)
        return true
    end
    return false
end

hook.Add("CreateEntityRagdoll", "Nagisa_Swimsuit_setup", function(ent, ragdoll)
    if IsValid(ent) and IsValid(ragdoll) and table.HasValue(models_for_character, ent:GetModel()) then
        SafeSetBodygroup(ragdoll, 'halo', 1)
    end
end)

hook.Add("DoPlayerDeath", "Nagisa_Swimsuit_player", function(ent, attacker, dmginfo)
    if IsValid(ent) and table.HasValue(models_for_character, ent:GetModel()) then
        timer.Simple(0.01, function()
            local ragdoll = ent:GetRagdollEntity()
            if IsValid(ragdoll) then
                SafeSetBodygroup(ragdoll, 'halo', 1)
            end
        end)
    end
end)