--Add Playermodel
player_manager.AddValidModel( "Nagisa_Swimsuit", "models/PM/Nagisa_Swimsuit_PM.mdl" )                         --PM模型
player_manager.AddValidHands( "Nagisa_Swimsuit", "models/arms/Nagisa_Swimsuit_arms.mdl", 0, "00000000" )      --PM手模

local Category = "Blue Archive-NEOWORLD"                                                                        --NPC MOD分类

local NPC = 
{
	Name = "Nagisa_Swimsuit(Friendly)",                                                            --友好NPC名字
	Class = "npc_citizen", 
	Health = "150",                                                                    --NPC血量
	KeyValues = { citizentype = 4 }, 
	Model = "models/NPC/Nagisa_Swimsuit_npc.mdl",                                                  --友好NPC模型
	Weapons = { "weapon_ar2","weapon_smg1"},                                           --NPC出生自带武器
	Category = Category
}

list.Set( "NPC", "Nagisa_Swimsuit_friendly", NPC )

local NPC =
{
	Name = "Nagisa_Swimsuit(Enemy)",                                                                --敌人NPC名字
	Class = "npc_combine_s",
	Health = "150",
	Numgrenades = "4",
	Model = "models/NPC/Nagisa_Swimsuit_npc.mdl",                                                  --敌人NPC模型
	Weapons = { "weapon_ar2","weapon_smg1"},
	Category = Category
}

list.Set( "NPC", "Nagisa_Swimsuit_enemy", NPC )
